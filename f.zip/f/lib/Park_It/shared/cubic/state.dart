abstract class AppStates{}

class AppChangeModeState extends AppStates {}

class AppInitialState extends AppStates{}