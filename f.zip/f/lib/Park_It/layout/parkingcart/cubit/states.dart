abstract class ParkingSlotsStates{}

class ParkingSlotsInitialStates extends ParkingSlotsStates{}

class ParkingSlotsLoadStates extends ParkingSlotsStates{}

class ParkingSlotsSuccessStates extends ParkingSlotsStates
{
  final String uId;
  ParkingSlotsSuccessStates(this.uId);
}

class ParkingSlotsErrorStates extends ParkingSlotsStates
{
  final String error;
  ParkingSlotsErrorStates(this.error);
}





