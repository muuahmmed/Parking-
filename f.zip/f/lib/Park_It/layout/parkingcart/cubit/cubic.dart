import 'package:bloc/bloc.dart';
import 'package:bloc_provider/bloc_provider.dart';
import 'package:f/Park_It/layout/parkingcart/cubit/states.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';


class ParkingSlotsCubit extends Cubit<ParkingSlotsStates> {
  ParkingSlotsCubit() : super(ParkingSlotsInitialStates());
  static ParkingSlotsCubit get(context) => BlocProvider.of(context);
  final reference = FirebaseDatabase.instance.ref('CarExistance');


}
