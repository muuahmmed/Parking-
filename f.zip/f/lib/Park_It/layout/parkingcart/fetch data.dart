import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';

class FetchData extends StatefulWidget {
  const FetchData({Key? key}) : super(key: key);

  @override
  State<FetchData> createState() => _FetchDataState();
}

class _FetchDataState extends State<FetchData> {

  Query dbRef = FirebaseDatabase.instance.ref().child('CarExistance');
  final reference = FirebaseDatabase.instance.ref('CarExistance');
  final ref = FirebaseDatabase.instance.ref("CarExistance");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
          children: [
            Expanded(
              child: FirebaseAnimatedList(
                shrinkWrap: true,
                query: ref,
                itemBuilder: (BuildContext context, DataSnapshot snapshot, Animation<double> animation, int index) {
                  return Column(
                    children: [
                      Text(
                          snapshot.child("CarExistance").value.toString()
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        )
    );
  }
}