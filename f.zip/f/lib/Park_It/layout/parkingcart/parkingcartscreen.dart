import 'package:f/Park_It/layout/parkingcart/fetch%20data.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../../components/components.dart';
import '../home/home_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {

  late DatabaseReference dbRef;
  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref().child('CarExistance');
  }

  @override

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Parking Cart',
          style: TextStyle(
              color: Colors.white
          ),
        ),
        leading: IconButton(
          onPressed: () {
            navigateTo(context, const Home());
          },
          icon: const Icon(
            Icons.arrow_back, color: Colors.white,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1/1,
          children: List.generate(3, (index) =>  buildButton(context, Icons.directions_car_filled_outlined, "slot ${index+1}"),),
        ),
      ),
    );
  }
}

Widget buildButton(BuildContext context,IconData icon, String label) {
  return SizedBox(
    width: 110,
    height: 100,
    child: ElevatedButton(
      onPressed: (){
        Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
            const FetchData(),
        ));
      },
      style: ElevatedButton.styleFrom(
        elevation: 12,
        shape: const RoundedRectangleBorder(
          side: BorderSide(color: Colors.green, width: 3, style: BorderStyle.solid),
        ),
        backgroundColor: Colors.transparent,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 80,
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 15, color: Colors.white),
          ),
        ],
      ),
    ),
  );
}