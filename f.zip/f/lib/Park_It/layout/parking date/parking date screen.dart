import 'package:flutter/material.dart';

import '../../components/components.dart';
import '../home/home_screen.dart';

class DataScreen extends StatefulWidget{
  const DataScreen({super.key});
  @override
  State<DataScreen> createState() => _DataScreenState();
}
class _DataScreenState extends State<DataScreen> {
  DateTime? _selectedDate1;
  DateTime? _selectedDate2;
  TimeOfDay? _selectedTime1From;
  TimeOfDay? _selectedTime1To;
  TimeOfDay? _selectedTime2From;
  TimeOfDay? _selectedTime2To;

  Future<void> _selectDate(BuildContext context, bool isFirst) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        if (isFirst) {
          _selectedDate1 = picked;
        } else {
          _selectedDate2 = picked;
        }
      });
    }
  }

  Future<void> _selectTime(BuildContext context, bool isFirst, bool isFrom) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        if (isFirst) {
          if (isFrom) {
            _selectedTime1From = picked;
          } else {
            _selectedTime1To = picked;
          }
        } else {
          if (isFrom) {
            _selectedTime2From = picked;
          } else {
            _selectedTime2To = picked;
          }
        }
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:  IconButton(
          onPressed: (){
            navigateTo(context,const Home());
          },
          icon: const Icon(
            Icons.arrow_back,color: Colors.white,
          ),

        ),
        title:const Text(
          'Date', style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 21
        ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_selectedDate1 != null)
              Text(
                'From Date: ${_selectedDate1!.toString().split(' ')[0]}',
                style: const TextStyle(fontSize: 20, color: Colors.white),
              ),
            ElevatedButton(
              onPressed: () {
                _selectDate(context, true);
              },
              child: const Text('Select Date From'),
            ),
            if (_selectedDate1 != null) ...[
              ElevatedButton(
                onPressed: () {
                  _selectTime(context, true, true);
                },
                child: const Text('Select Start Time From'),
              ),
              if (_selectedTime1From != null)
                Text(
                  'Start Time From: ${_selectedTime1From!.format(context)}',
                  style: const TextStyle(fontSize: 20, color: Colors.white),
                ),
              ElevatedButton(
                onPressed: () {
                  _selectTime(context, true, false);
                },
                child: const Text('Select End Time From'),
              ),
              if (_selectedTime1To != null)
                Text(
                  'End Time From: ${_selectedTime1To!.format(context)}',
                  style: const TextStyle(fontSize: 20, color: Colors.white),
                ),
            ],
            const SizedBox(height: 20),
            if (_selectedDate2 != null)
              Text(
                'To Date: ${_selectedDate2!.toString().split(' ')[0]}',
                style: const TextStyle(fontSize: 20, color: Colors.white),
              ),
            ElevatedButton(
              onPressed: () {
                _selectDate(context, false);
              },
              child: const Text('Select Date To'),
            ),
            if (_selectedDate2 != null) ...[
              ElevatedButton(
                onPressed: () {
                  _selectTime(context, false, true);
                },
                child: const Text('Select Start Time To'),
              ),
              if (_selectedTime2From != null)
                Text(
                  'Start Time To: ${_selectedTime2From!.format(context)}',
                  style: const TextStyle(fontSize: 20, color: Colors.white),
                ),
              ElevatedButton(
                onPressed: () {
                  _selectTime(context, false, false);
                },
                child: const Text('Select End Time To'),
              ),
              if (_selectedTime2To != null)
                Text(
                  'End Time To: ${_selectedTime2To!.format(context)}',
                  style: const TextStyle(fontSize: 20, color: Colors.white),
                ),
            ],
          ],
        ),
      ),

    );
  }
}