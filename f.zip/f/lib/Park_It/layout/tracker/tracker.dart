import 'package:flutter/material.dart';
import 'package:f/Park_It/components/components.dart';

import '../home/home_screen.dart';

class Tracker extends StatefulWidget{
  const Tracker({super.key});

  @override
  State<Tracker> createState() => _TrackerState();
}

class _TrackerState extends State<Tracker> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:  IconButton(
          onPressed: (){
            navigateTo(context,const Home());
            },
          icon: const Icon(
            Icons.arrow_back,color: Colors.white,
          ),

        ),
        title: const Text(
          'Tracker',
          style: TextStyle(
            color: Colors.white,

          ),
        ),
      ),
      backgroundColor:  const Color(0xff0d2331),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Image(image: AssetImage("assets/images/wifi.png"),height: 250,width: double.infinity,color: Colors.white,),

            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                width: 200,
                height: 47,
                color: Colors.redAccent,
                child: TextButton(onPressed: ()
                {

                },
                    child: const Text(
                  'TRACKER',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                )),
              ),
            ),
          ],
        ),
      ),
    );
  }
}