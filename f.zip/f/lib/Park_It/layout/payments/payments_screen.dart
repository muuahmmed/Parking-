

import 'package:flutter/material.dart';
import 'package:f/Park_It/components/components.dart';
import 'package:f/Park_It/layout/home/home_screen.dart';
import 'package:flutter_paypal_payment/flutter_paypal_payment.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({super.key});

  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment',style: TextStyle(color: Colors.white),),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back,color: Colors.white,),
          onPressed: () {
            navigateAndFinish(context, const Home());
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const Text('Here you can pay for your time you spent on your slot',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25),),
            const SizedBox(height: 50,),
            const Divider(color: Colors.white,),
            const SizedBox(height: 25,),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 50,),
                  Text('Order Subtotal: 42.97',style: TextStyle(fontSize: 15),),
                  SizedBox(
                    height: 15,
                  ),
                  Text('Discount: 0\$',style: TextStyle(fontSize: 15)),
                  SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Total:',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '\$50.97',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: SizedBox(
                height: 80,
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) => PaypalCheckoutView(
                        sandboxMode: true,
                        clientId: "YOUR CLIENT ID",
                        secretKey: "YOUR SECRET KEY",
                        transactions: const [
                          {
                            "amount": {
                              "total": "100",
                              "currency": "USD",
                              "details": {
                                "subtotal": "100",
                                "shipping": "0",
                                "shipping_discount": 0
                              }
                            },
                            "description": "The payment transaction description.",
                            // "payment_options": {
                            //   "allowed_payment_method":
                            //       "INSTANT_FUNDING_SOURCE"
                            // },
                            "item_list": {
                              "items":
                                {
                                  "slot number": "Apple",
                                  "time": "00:00",
                                  "price for minute": '0.6',
                                  "currency": "USD"
                                },
                            }
                          }
                        ],
                        note: "Contact us for any questions on your order.",
                        onSuccess: (Map params) async {
                          //log("onSuccess: $params");
                          Navigator.pop(context);
                        },
                        onError: (error) {
                         // log("onError: $error");
                          Navigator.pop(context);
                        },
                        onCancel: () {
                          print('cancelled:');
                          Navigator.pop(context);
                        },
                      ),
                    ));
                  },
                  child: const Text('Complete Payment',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize:24 )),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}