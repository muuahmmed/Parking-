package com.example.f

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
